
public class Fortigaki extends Kartela_Oximatos{
	
	private Double load; // ωφέλιμο φορτίο

	public Fortigaki(String make, String sign_num, String model, int yearOfMake, Double load) {
		super(make, sign_num, model, yearOfMake);
		this.load = load;
	}
	
	

}
