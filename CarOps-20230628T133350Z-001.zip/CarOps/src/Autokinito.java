
public class Autokinito extends Kartela_Oximatos{   // δημιουργια κληρονομικοτητας 

	
	// Δημιουργια του constructor
	
	public Autokinito(String make, String sign_num, String model, int yearOfMake) {
		super(make, sign_num, model, yearOfMake);
		
	}
	

}
