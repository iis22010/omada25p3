
public class Dikyklo extends Kartela_Oximatos{

	private int cc;         // cc = κυβικά 

	
	public Dikyklo(String make, String sign_num, String model, int yearOfMake, int cc) {
		super(make, sign_num, model, yearOfMake);
		this.cc = cc;
	}
	
	
	
	
	
}
